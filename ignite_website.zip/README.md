
# Ignite Resource Centre — Static Website

Files in this package are ready to upload to Netlify or GitHub Pages.
Included files:
- index.html, about.html, programs.html, team.html, contact.html
- styles.css, logo.svg
- images/ (director photos and other uploaded images)

## Quick publish to Netlify (recommended)
1. Sign up at https://www.netlify.com and create a new site from drag & drop.
2. Drag the entire contents of this folder (all files and the images folder) to Netlify's "Sites" area.
3. The site will be deployed and a free *.netlify.app domain will be assigned. To receive form submissions, Netlify Forms is already configured (the contact form uses `data-netlify="true"`).

## Quick publish to GitHub Pages
1. Create a GitHub repository and push the files to the `main` branch.
2. In the repository settings -> Pages -> Source, choose `main` branch and root folder.
3. Your site will be available at https://yourusername.github.io/repository-name

## Notes
- Contact form uses Netlify Forms. If you host on GitHub Pages, the form won't work by default (use Formspree or change to mailto).
- To use your custom domain, configure DNS with your registrar and add settings in Netlify or GitHub Pages settings.
